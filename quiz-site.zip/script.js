const SUPABASE_URL = "https://rwuoouzstknomtrmgpzu.supabase.co";
const SUPABASE_KEY = "sb_publishable_wZxaP67g8pK9Fad1z32mzQ_RVc-Suey";
const ADMIN_PIN = "admin123";

const db = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

// الأسئلة الـ 20 بدون إيموجيات وخيارات مختصرة وجميلة
const QUESTIONS_BANK = [
  { q: "شو أكتر صفة بتميزني؟", options: ["طيبة القلب", "الصراحة المباشرة", "خفة الدم", "الغموض والهدوء"] },
  { q: "أنا حساسة ولا باردة؟", options: ["حساسة جدا", "باردة الأعصاب", "موازنة بين الاثنين", "حسب الشخص والموقف"] },
  { q: "شو الشي اللي بيعصبني بسرعة؟", options: ["الكذب واللف والدوران", "البطء بالفهم والحركة", "مقاطعتي أثناء الكلام", "البرود والتطنيش"] },
  { q: "لما أزعل بحب أحكي ولا أسكت؟", options: ["أسكت وأعزل نفسي", "أنفجر وأعاتب فوراً", "أحكي ببرود وجدية", "حسب مين الغلطان"] },
  { q: "أنا اجتماعية ولا بحب الهدوء؟", options: ["اجتماعية مع الكل", "أعشق الهدوء والعزلة", "مع ناسي المقربين فقط", "حسب المود والوقت"] },
  { q: "شو أكتر شي بخاف منه؟", options: ["فقدان شخص غالي", "الفشل وعدم الإنجاز", "خذلان الأقارب", "المستقبل المجهول"] },
  { q: "شو الشي اللي ممكن يفرحني بسرعة؟", options: ["أكلة طيبة بحبها", "كلمة حلوة وجبر خاطر", "تذكر تفصيل صغير عني", "رسالة مفاجئة لطيفة"] },
  { q: "أنا عنيدة ولا بقتنع بسرعة؟", options: ["عنيدة لأبعد حد", "بقتنع بالمنطق والدليل", "راسي يابس شوي", "حسب الموضوع"] },
  { q: "شو الشي اللي ما بسامح عليه؟", options: ["الخيانة والغدر", "جرح الكرامة والتقليل", "الكذب المتعمد", "الاستغفال واستغلال الطيبة"] },
  { q: "اذا اختفيت فجأة شو غالباً بكون عم أعمل؟", options: ["نائمة نوم عميق", "أحضر مسلسل أو فيلم", "فاصلة عن العالم تماماً", "أسمع موسيقى ورايقة"] },
  { q: "شو الشي اللي بخليني أفقد ثقتي بشخص؟", options: ["الحكي من ورا ظهري", "إخلاف الوعد والعهود", "النفاق والمجاملة الزائدة", "التغير الفجائي بالمعاملة"] },
  { q: "اذا صار معي موقف محرج بضحك ولا بتوتر؟", options: ["أفرط ضحك بتسليك", "أتوتر ويصير وجهي أحمر", "أسكت وأغير الموضوع", "ولا كأنه صار أصلاً"] },
  { q: "شو الشي اللي مستحيل ملّ منه؟", options: ["النوم والسهر", "تصفح التلفون", "سماع الأغاني والموسيقى", "الأكل وتجربة المطاعم"] },
  { q: "شو أكتر شي ممكن يخليني ابكي؟", options: ["القهر والظلم", "الشوق والحنين للأيام", "مشهد مؤثر جداً", "تراكم التعب والضغط"] },
  { q: "شو اكتر شي بعمله لما أكون مالة؟", options: ["تيك توك وريلز بلا هدف", "أفتش بالبراد عن أكل", "أهرب للنوم", "أطلع أغير جو لوحدي"] },
  { q: "مين مغنيي المفضل؟", options: ["فيروز", "أصالة نصري", "كاظم الساهر", "ناصيف زيتون أو الشامي"] },
  { q: "شو نوع الافلام الي بحب اني احضره؟", options: ["رعب وغموض وإثارة", "دراما وقصص واقعية", "أكشن وحماس", "كوميديا وخفيف"] },
  { q: "شو اكتر تطبيق بستخدمه؟", options: ["واتساب", "إنستغرام", "تيك توك", "تليجرام"] },
  { q: "شو اكتر جملة بكررها؟", options: ["عادي مو فارقة", "خليني ساكتة أحسن", "عن جد عم تحكي؟", "خلص مو مشكلة"] },
  { q: "شو البلد يلي اتمنى زورها؟", options: ["إيطاليا", "سويسرا", "تركيا", "اليابان"] }
];

let creatorName = "";
let currentCreatorQuestionIndex = 0;
let collectedQuestionsForChallenge = [];

let activeChallenge = null;
let existingPlayers = [];
let currentPlayerName = "";
let playIndex = 0;
let playerScore = 0;
let playerAnswersLog = [];

let toastTimeout;
function showNotice(msg, icon = "✨") {
  const toast = document.getElementById("custom-toast");
  document.getElementById("toast-icon").textContent = icon;
  document.getElementById("toast-text").textContent = msg;
  toast.classList.add("show");
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.remove("show"), 3000);
}

function showView(viewId) {
  document.querySelectorAll(".view").forEach(v => v.classList.add("hidden"));
  document.getElementById(viewId).classList.remove("hidden");
  window.scrollTo(0, 0);
}

window.addEventListener("DOMContentLoaded", async () => {
  const params = new URLSearchParams(window.location.search);
  const challengeId = params.get("id");
  const isAdmin = params.get("admin");

  if (isAdmin === "1") {
    showView("view-admin");
    return;
  }

  if (challengeId) {
    await loadChallengeForPlayer(challengeId);
  } else {
    showView("view-home");
  }
});

// ==========================================
// 1. تدفق إنشاء التحدي خطوة بخطوة
// ==========================================
function startCreateFlow() {
  creatorName = "";
  currentCreatorQuestionIndex = 0;
  collectedQuestionsForChallenge = [];
  
  document.getElementById("creator-name-input").value = "";
  document.getElementById("creator-name-box").classList.remove("hidden");
  document.getElementById("creator-question-box").classList.add("hidden");
  
  showView("view-create-step");
}

function confirmCreatorName() {
  const nameVal = document.getElementById("creator-name-input").value.trim();
  if (!nameVal) {
    showNotice("اكتب اسمك أو لقبك بالأول من فضلك!", "✍️");
    return;
  }
  creatorName = nameVal;
  document.getElementById("creator-name-box").classList.add("hidden");
  document.getElementById("creator-question-box").classList.remove("hidden");
  renderNextCreatorQuestion();
}

function renderNextCreatorQuestion() {
  if (currentCreatorQuestionIndex >= QUESTIONS_BANK.length) {
    finishChallengeEarly();
    return;
  }

  const item = QUESTIONS_BANK[currentCreatorQuestionIndex];
  document.getElementById("creator-progress-badge").textContent = `السؤال ${currentCreatorQuestionIndex + 1} من ${QUESTIONS_BANK.length}`;
  document.getElementById("creator-q-title").textContent = item.q;
  document.getElementById("creator-custom-input").value = "";

  const grid = document.getElementById("creator-options-grid");
  grid.innerHTML = item.options.map((opt, oIdx) => `
    <button type="button" class="choice-chip" onclick="selectCreatorAnswer(${oIdx})">
      ${escapeHtml(opt)}
    </button>
  `).join("");
}

function selectCreatorAnswer(optionIdx) {
  const item = QUESTIONS_BANK[currentCreatorQuestionIndex];
  collectedQuestionsForChallenge.push({
    q: item.q,
    options: item.options,
    answer: optionIdx
  });

  currentCreatorQuestionIndex++;
  showNotice("تم حفظ الإجابة بنجاح ✓", "👍");
  renderNextCreatorQuestion();
}

function saveCustomAndNext() {
  const customVal = document.getElementById("creator-custom-input").value.trim();
  const item = QUESTIONS_BANK[currentCreatorQuestionIndex];

  let finalOptions = [...item.options];
  let correctIdx = 0;

  if (customVal) {
    finalOptions = [item.options[0], item.options[1], item.options[2], customVal];
    correctIdx = 3;
  }

  collectedQuestionsForChallenge.push({
    q: item.q,
    options: finalOptions,
    answer: correctIdx
  });

  currentCreatorQuestionIndex++;
  showNotice("تم اعتماد إجابتك وانتقلت للسؤال التالي!", "🚀");
  renderNextCreatorQuestion();
}

function skipThisQuestion() {
  currentCreatorQuestionIndex++;
  showNotice("تم تخطي السؤال", "⏭️");
  renderNextCreatorQuestion();
}

async function finishChallengeEarly() {
  if (collectedQuestionsForChallenge.length < 2) {
    showNotice("يرجى الإجابة على سؤالين على الأقل قبل الإنهاء!", "🎯");
    return;
  }

  showNotice("جاري حفظ التحدي وتوليد الرابط...", "⏳");

  const { data, error } = await db
    .from("challenges")
    .insert([{ creator_name: creatorName, questions: collectedQuestionsForChallenge }])
    .select()
    .single();

  if (error || !data) {
    showNotice("حدث خطأ أثناء الاتصال بقاعدة البيانات!", "⚠️");
    console.error(error);
    return;
  }

  activeChallenge = data;
  const shareUrl = `${window.location.origin}${window.location.pathname}?id=${data.id}`;
  document.getElementById("share-url-input").value = shareUrl;
  showView("view-share");
  showNotice("صار رابط تحديك جاهز للمشاركة!", "🥳");
}

function copyShareUrl() {
  const input = document.getElementById("share-url-input");
  navigator.clipboard.writeText(input.value);
  showNotice("تم نسخ الرابط بنجاح! أرسله لأصدقائك", "✅");
}

function shareWhatsApp() {
  const url = document.getElementById("share-url-input").value;
  const text = `عملت تحدي شخصي عني! 😎🔥\nفوتوا شوفوا كم سؤال رح تعرفوا صح، والنتائج عم تطلع عندي:\n${url}`;
  window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank");
}

function openChallengeDirectly() {
  window.location.href = document.getElementById("share-url-input").value;
}

// ==========================================
// 2. تشغيل الصديق للتحدي
// ==========================================
async function loadChallengeForPlayer(challengeId) {
  const { data: chData, error } = await db
    .from("challenges")
    .select("*")
    .eq("id", challengeId)
    .single();

  if (error || !chData) {
    showNotice("هاد الرابط غير صحيح أو انتهت صلاحيته!", "❌");
    showView("view-home");
    return;
  }

  activeChallenge = chData;
  document.getElementById("intro-creator-name").textContent = chData.creator_name;
  document.getElementById("intro-q-count").textContent = chData.questions.length;

  await fetchLeaderboard(challengeId, "intro-leaderboard");
  showView("view-play-intro");
}

async function fetchLeaderboard(challengeId, containerId) {
  const { data: results } = await db
    .from("results")
    .select("*")
    .eq("challenge_id", challengeId)
    .order("score", { ascending: false })
    .order("created_at", { ascending: true });

  existingPlayers = results || [];
  const box = document.getElementById(containerId);

  if (!existingPlayers.length) {
    box.innerHTML = `<p class="subtitle" style="margin:0;">ما حدا جاوب لسا.. كن أول من يفتتح الترتيب! 🚀</p>`;
    return;
  }

  box.innerHTML = existingPlayers.map((r, idx) => {
    const medal = idx === 0 ? "🥇" : idx === 1 ? "🥈" : idx === 2 ? "🥉" : `#${idx + 1}`;
    const badgeInfo = getHumanComment(r.score, r.total_questions);
    return `
      <div class="leader-row" onclick="inspectPlayerAnswers(${idx})">
        <div class="leader-info">
          <span class="leader-rank">${medal}</span>
          <div>
            <span class="leader-name">${escapeHtml(r.player_name)}</span>
            <span class="leader-tag">${badgeInfo.tag}</span>
          </div>
        </div>
        <div class="leader-right">
          <span class="inspect-btn">كشف الإجابات 👀</span>
          <span class="leader-score">${r.score}/${r.total_questions}</span>
        </div>
      </div>
    `;
  }).join("");
}

function inspectPlayerAnswers(playerIdx) {
  const record = existingPlayers[playerIdx];
  if (!record) return;

  document.getElementById("modal-player-title").textContent =
    `إجابات ${record.player_name} (${record.score} من ${record.total_questions})`;

  const listBox = document.getElementById("modal-answers-list");
  const details = Array.isArray(record.answers) && record.answers.length ? record.answers : null;

  if (!details) {
    listBox.innerHTML = `<p class="subtitle">تفاصيل الإجابات غير متوفرة لهذا المشارك القديم.</p>`;
  } else {
    listBox.innerHTML = details.map((d, i) => `
      <div class="ans-detail-item ${d.isCorrect ? 'is-right' : 'is-wrong'}">
        <div class="ans-q">${i + 1}. ${escapeHtml(d.q)}</div>
        <div class="ans-picked">
          ${d.isCorrect ? '✅ جاوب صح:' : '❌ جاوب خطأ:'} <strong>${escapeHtml(d.pickedText)}</strong>
        </div>
        ${!d.isCorrect ? `<div class="ans-correct-note">💡 الجواب الصحيح: ${escapeHtml(d.correctText)}</div>` : ''}
      </div>
    `).join("");
  }

  document.getElementById("answers-modal").classList.remove("hidden");
}

function closeModal() {
  document.getElementById("answers-modal").classList.add("hidden");
}

function startPlaying() {
  const nameEl = document.getElementById("player-name");
  const enteredName = nameEl.value.trim();

  if (!enteredName) {
    showNotice("اكتب اسمك الأول لكي يظهر بالترتيب!", "✍️");
    nameEl.focus();
    return;
  }

  const isDuplicate = existingPlayers.some(
    p => p.player_name.trim().toLowerCase() === enteredName.toLowerCase()
  );

  if (isDuplicate) {
    showNotice("هاد الاسم مستخدم بالتحدي! أضف لقباً أو رقماً بجانبه.", "⚠️");
    nameEl.focus();
    return;
  }

  currentPlayerName = enteredName;
  playIndex = 0;
  playerScore = 0;
  playerAnswersLog = [];

  showView("view-play-quiz");
  renderPlayQuestion();
}

function renderPlayQuestion() {
  const qs = activeChallenge.questions;
  const item = qs[playIndex];

  document.getElementById("play-progress").textContent = `سؤال ${playIndex + 1} من ${qs.length}`;
  const pct = Math.round(((playIndex + 1) / qs.length) * 100);
  document.getElementById("progress-fill").style.width = `${pct}%`;

  document.getElementById("play-q-text").textContent = item.q;

  const optsBox = document.getElementById("play-options");
  optsBox.innerHTML = "";

  item.options.forEach((opt, idx) => {
    const btn = document.createElement("button");
    btn.className = "choice-chip";
    btn.textContent = opt;
    btn.onclick = () => handlePlayerAnswer(idx, item, btn);
    optsBox.appendChild(btn);
  });
}

function handlePlayerAnswer(chosenIdx, item, clickedBtn) {
  const allBtns = document.querySelectorAll("#play-options .choice-chip");
  allBtns.forEach(b => (b.disabled = true));

  const isCorrect = chosenIdx === item.answer;
  if (isCorrect) {
    clickedBtn.style.background = "var(--success)";
    clickedBtn.style.color = "#fff";
    playerScore++;
  } else {
    clickedBtn.style.background = "var(--danger)";
    clickedBtn.style.color = "#fff";
    if (allBtns[item.answer]) {
      allBtns[item.answer].style.background = "var(--success)";
      allBtns[item.answer].style.color = "#fff";
    }
  }

  playerAnswersLog.push({
    q: item.q,
    pickedText: item.options[chosenIdx],
    correctText: item.options[item.answer],
    isCorrect: isCorrect
  });

  setTimeout(async () => {
    playIndex++;
    if (playIndex >= activeChallenge.questions.length) {
      await finishQuizAndSave();
    } else {
      renderPlayQuestion();
    }
  }, 850);
}

async function finishQuizAndSave() {
  const total = activeChallenge.questions.length;

  const { error } = await db.from("results").insert([{
    challenge_id: activeChallenge.id,
    player_name: currentPlayerName,
    score: playerScore,
    total_questions: total,
    answers: playerAnswersLog
  }]);

  if (error) {
    await db.from("results").insert([{
      challenge_id: activeChallenge.id,
      player_name: currentPlayerName,
      score: playerScore,
      total_questions: total
    }]);
  }

  document.getElementById("result-score").textContent = playerScore;
  document.getElementById("result-total").textContent = total;
  document.getElementById("res-creator-name").textContent = activeChallenge.creator_name;

  const feedback = getHumanComment(playerScore, total);
  document.getElementById("result-emoji").textContent = feedback.emoji;
  document.getElementById("result-comment").textContent = feedback.comment;

  showView("view-result");

  if (playerScore === total && typeof confetti === "function") {
    confetti({ particleCount: 150, spread: 85, origin: { y: 0.6 } });
  }

  await fetchLeaderboard(activeChallenge.id, "result-leaderboard");
}

function getHumanComment(score, total) {
  const ratio = score / total;
  if (ratio === 1) {
    return { emoji: "👑🔥", tag: "توأم الروح والعشرة", comment: "علامة كاملة! أنت تحفظه أكثر من نفسه!" };
  } else if (ratio >= 0.7) {
    return { emoji: "😍👏", tag: "صديق أصيل وقريب", comment: "رائع جداً! تعرفه حق المعرفة." };
  } else if (ratio >= 0.4) {
    return { emoji: "🤨☕", tag: "نص نص.. تحتاج قعدة", comment: "ليس سيئاً، لكن يبدو أنكم بحاجة لاسترجاع الذكريات!" };
  } else {
    return { emoji: "🚫😂", tag: "صديق مزيف بامتياز", comment: "يا حيف على الصحبة! شكلك دخلت بالخطأ!" };
  }
}

function goCreateFromResult() {
  window.history.pushState({}, "", window.location.pathname);
  startCreateFlow();
}

async function verifyAdmin() {
  const pass = document.getElementById("admin-pass").value;
  if (pass !== ADMIN_PIN) {
    showNotice("الرمز السري غير صحيح!", "🔒");
    return;
  }

  document.getElementById("admin-auth-box").classList.add("hidden");
  document.getElementById("admin-dashboard").classList.remove("hidden");

  const { data: challenges } = await db.from("challenges").select("*").order("created_at", { ascending: false });
  const { data: results } = await db.from("results").select("*");

  const chList = challenges || [];
  const resList = results || [];

  document.getElementById("stat-total-challenges").textContent = chList.length;
  document.getElementById("stat-total-players").textContent = resList.length;

  let avg = 0;
  if (resList.length > 0) {
    const sumRatios = resList.reduce((acc, r) => acc + (r.score / r.total_questions), 0);
    avg = Math.round((sumRatios / resList.length) * 100);
  }
  document.getElementById("stat-avg-score").textContent = `${avg}%`;

  const listContainer = document.getElementById("admin-challenges-list");
  listContainer.innerHTML = chList.map(c => {
    const playersForThis = resList.filter(r => r.challenge_id === c.id).length;
    const link = `${window.location.origin}${window.location.pathname}?id=${c.id}`;
    return `
      <div class="leader-row" onclick="window.open('${link}', '_blank')">
        <div class="leader-info">
          <span class="leader-rank">🎯</span>
          <div>
            <span class="leader-name">${escapeHtml(c.creator_name)}</span>
            <span class="leader-tag">${c.questions.length} أسئلة • ${playersForThis} مشاركين</span>
          </div>
        </div>
        <span class="leader-score">معاينة ↗</span>
      </div>
    `;
  }).join("");
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, s => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[s]));
}
